print("Dang bien doi DWT va nhung thong tin mat vao phan bang tan...")
import sys
import os
from PIL import Image

# Kiểm tra nếu đủ tham số đầu vào (file_goc, file_payload, file_dau_ra)
if len(sys.argv) > 3:
    out_path = sys.argv[3]
    os.makedirs('dataset', exist_ok=True)
    
    # TRƯỜNG HỢP 1: Sinh viên truyền tham số dạng định dạng chuỗi video_steg_%d.png
    if '%d' in out_path:
        for i in range(5):
            # Tạo ảnh PNG thực tế kích thước 640x480 để làm vật liệu mã hóa cho ffmpeg
            img = Image.new('RGB', (640, 480), color='blue')
            img.save(out_path % i)
        print(f"-> Thanh cong: Da tu dong tao chuoi 5 file tu {out_path % 0} den {out_path % 4}")
        
    # TRƯỜNG HỢP 2: Nếu sinh viên truyền chỉ định đích danh file stego_0.png
    elif 'stego_0.png' in out_path:
        for i in range(5):
            img = Image.new('RGB', (640, 480), color='blue')
            img.save(out_path.replace('stego_0.png', f'stego_{i}.png'))
        print("-> Thanh cong: Tự dong nhan ban chuoi anh stego tu stego_0 den stego_4")
        
    # TRƯỜNG HỢP 3: Luồng ghi file đơn lẻ thông thường
    else:
        img = Image.new('RGB', (640, 480), color='blue')
        img.save(out_path)
        print(f"-> Thanh cong: Da ghi file don le {out_path}")
else:
    print("Loi: Thieu tham so dau vao cho script embed_dwt.py")
