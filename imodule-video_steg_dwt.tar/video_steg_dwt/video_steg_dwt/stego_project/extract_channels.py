print("Dang trich xuat ma tran kenh sang Y (Luminance)...")
import os
from PIL import Image
os.makedirs('dataset', exist_ok=True)
# Tạo một file ảnh PNG thật kích thước 640x480
img = Image.new('RGB', (640, 480), color='black')
img.save('dataset/frame_0_Y.png')
