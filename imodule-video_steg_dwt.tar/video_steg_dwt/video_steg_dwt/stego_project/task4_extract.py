# Sinh viên viết tiếp code trích xuất thông tin DWT và tính BER vào đây
print("Chuong trinh trich xuat thong tin an...")
