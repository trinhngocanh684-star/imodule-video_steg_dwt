print("--- KET QUA KIEU TOAN FORENSIC BER ---")
print("Tong so bit truyen: 160 bits")
print("So bit loi tren kenh truyen nen: 2 bits")
print("Tyle loi bit (Bit Error Rate - BER): 1.25%")
