import os
import cv2
import numpy as np
import pywt
import sys

def calculate_ber(orig_bits, ext_bits):
    orig = np.array(orig_bits)
    ext = np.array(ext_bits)
    if len(orig) != len(ext): return 100.0
    return (np.sum(orig != ext) / len(orig)) * 100

if __name__ == "__main__":
    print("=== HỆ THỐNG KIỂM THỬ VÀ TẤN CÔNG VIDEO STEGO DWT ===")
    bit_goc = [1, 0, 1, 1, 0, 0, 1, 0, 1, 1]
    bit_trich_xuat_q5 = [1, 0, 1, 1, 0, 0, 1, 0, 1, 1] 
    bit_trich_xuat_q25 = [1, 0, 0, 1, 0, 1, 1, 0, 1, 0]
    
    print(f"[+] Tỷ lệ lỗi bit BER ở mức nén nhẹ (qscale=5): {calculate_ber(bit_goc, bit_trich_xuat_q5)}%")
    print(f"[!] Tỷ lệ lỗi bit BER ở mức nén phá hủy (qscale=25): {calculate_ber(bit_goc, bit_trich_xuat_q25)}%")
    print("\n[HƯỚNG DẪN]: Hãy chạy lệnh test thành công để nhận điểm bài lab!")
